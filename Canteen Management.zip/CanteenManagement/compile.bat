@echo off
rem =============================================================
rem  compile.bat
rem  Compiles all Java source files in src\canteen
rem  Output .class files go to the out\ directory
rem =============================================================

set PROJECT_ROOT=%~dp0
set SRC_DIR=%PROJECT_ROOT%src
set OUT_DIR=%PROJECT_ROOT%out
set LIB_DIR=%PROJECT_ROOT%lib
set JAR=%LIB_DIR%\mysql-connector-j-9.7.0.jar

echo -----------------------------------------------
echo  Compiling Canteen Management System
echo -----------------------------------------------

if not exist "%JAR%" (
    echo [ERROR] MySQL connector JAR not found at:
    echo         %JAR%
    echo Please copy the JAR into the lib\ folder.
    pause
    exit /b 1
)

if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"

javac -cp "%JAR%" -d "%OUT_DIR%" ^
    "%SRC_DIR%\canteen\DBConfig.java" ^
    "%SRC_DIR%\canteen\DatabaseConnection.java" ^
    "%SRC_DIR%\canteen\FoodItem.java" ^
    "%SRC_DIR%\canteen\Order.java" ^
    "%SRC_DIR%\canteen\OrderDetail.java" ^
    "%SRC_DIR%\canteen\FoodDAO.java" ^
    "%SRC_DIR%\canteen\OrderDAO.java" ^
    "%SRC_DIR%\canteen\CanteenService.java" ^
    "%SRC_DIR%\canteen\Main.java" ^
    "%SRC_DIR%\canteen\WebServer.java"

if %ERRORLEVEL% == 0 (
    echo [SUCCESS] Compilation complete. Run run.bat to start the app.
) else (
    echo [FAILED]  Compilation errors. Fix them and retry.
)
pause
