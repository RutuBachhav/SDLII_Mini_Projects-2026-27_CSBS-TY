package canteen;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the Orders and Order_Details tables.
 * Handles order creation (with full JDBC transaction) and history retrieval.
 */
public class OrderDAO {

    private final FoodDAO foodDAO = new FoodDAO();

    // ------------------------------------------------------------------ //
    // CREATE ORDER (transactional)
    // ------------------------------------------------------------------ //

    /**
     * Persists a complete order to the database inside a single JDBC transaction.
     * Steps performed atomically:
     *   1. Insert a row into Orders.
     *   2. For each detail: insert a row into Order_Details.
     *   3. Reduce Food_Items.quantity_available for each item.
     * Commits only when all steps succeed; rolls back on any error.
     *
     * @param details list of OrderDetail objects prepared by CanteenService
     * @return the Order object with the new orderId and totalAmount set
     * @throws SQLException if any DB operation fails (transaction is rolled back)
     */
    public Order createOrder(List<OrderDetail> details) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        conn.setAutoCommit(false);          // BEGIN TRANSACTION

        try {
            // --- Step 1: calculate total ---
            BigDecimal total = details.stream()
                    .map(OrderDetail::getSubtotal)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            // --- Step 2: insert into Orders ---
            int newOrderId;
            String insertOrder = "INSERT INTO Orders (order_date, total_amount) VALUES (NOW(), ?)";
            try (PreparedStatement ps = conn.prepareStatement(
                    insertOrder, Statement.RETURN_GENERATED_KEYS)) {
                ps.setBigDecimal(1, total);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (!rs.next()) throw new SQLException("Failed to retrieve generated order_id.");
                    newOrderId = rs.getInt(1);
                }
            }

            // --- Step 3: insert Order_Details + reduce stock ---
            String insertDetail =
                    "INSERT INTO Order_Details (order_id, food_id, quantity, unit_price, subtotal) "
                  + "VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(insertDetail)) {
                for (OrderDetail d : details) {
                    // Reduce stock (performs FOR UPDATE lock check)
                    foodDAO.reduceStock(conn, d.getFoodId(), d.getQuantity());

                    ps.setInt(1, newOrderId);
                    ps.setInt(2, d.getFoodId());
                    ps.setInt(3, d.getQuantity());
                    ps.setBigDecimal(4, d.getUnitPrice());
                    ps.setBigDecimal(5, d.getSubtotal());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            conn.commit();                  // COMMIT

            Order order = new Order(newOrderId, LocalDateTime.now(), total);
            order.setDetails(new ArrayList<>(details));
            return order;

        } catch (SQLException e) {
            conn.rollback();                // ROLLBACK
            throw e;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    // ------------------------------------------------------------------ //
    // FETCH ALL ORDERS (summary)
    // ------------------------------------------------------------------ //

    /** Returns all orders (order_id, order_date, total_amount), newest first. */
    public List<Order> getAllOrders() throws SQLException {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT order_id, order_date, total_amount FROM Orders ORDER BY order_id DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Order(
                        rs.getInt("order_id"),
                        rs.getTimestamp("order_date").toLocalDateTime(),
                        rs.getBigDecimal("total_amount")));
            }
        }
        return list;
    }

    // ------------------------------------------------------------------ //
    // FETCH ORDER DETAILS
    // ------------------------------------------------------------------ //

    /**
     * Returns all detail lines for a given order_id.
     * Joins Order_Details with Food_Items to get the food name.
     */
    public List<OrderDetail> getOrderDetails(int orderId) throws SQLException {
        List<OrderDetail> list = new ArrayList<>();
        String sql =
                "SELECT od.detail_id, od.order_id, od.food_id, f.food_name, "
              + "       od.quantity, od.unit_price, od.subtotal "
              + "FROM Order_Details od "
              + "JOIN Food_Items f ON od.food_id = f.food_id "
              + "WHERE od.order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderDetail d = new OrderDetail();
                    d.setDetailId(rs.getInt("detail_id"));
                    d.setOrderId(rs.getInt("order_id"));
                    d.setFoodId(rs.getInt("food_id"));
                    d.setFoodName(rs.getString("food_name"));
                    d.setQuantity(rs.getInt("quantity"));
                    d.setUnitPrice(rs.getBigDecimal("unit_price"));
                    d.setSubtotal(rs.getBigDecimal("subtotal"));
                    list.add(d);
                }
            }
        }
        return list;
    }

    // ------------------------------------------------------------------ //
    // FETCH SINGLE ORDER HEADER
    // ------------------------------------------------------------------ //

    /** Returns the Order header (without details) for the given order_id, or null. */
    public Order getOrderById(int orderId) throws SQLException {
        String sql = "SELECT order_id, order_date, total_amount FROM Orders WHERE order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Order(
                            rs.getInt("order_id"),
                            rs.getTimestamp("order_date").toLocalDateTime(),
                            rs.getBigDecimal("total_amount"));
                }
            }
        }
        return null;
    }
}
