package canteen;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Application service layer.
 * Contains all business logic, user-interaction helpers,
 * and formatted output methods used by Main.java.
 */
public class CanteenService {

    private final FoodDAO  foodDAO  = new FoodDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    private static final DateTimeFormatter DT_FMT =
            DateTimeFormatter.ofPattern("dd-MMM-yyyy  HH:mm:ss");

    // ================================================================== //
    //  FEATURE A — Add Food Item
    // ================================================================== //

    public void addFoodItem(Scanner sc) {
        System.out.println("\n--- ADD FOOD ITEM ---");

        // --- food name ---
        String name;
        while (true) {
            System.out.print("Enter food name: ");
            name = sc.nextLine().trim();
            if (!name.isEmpty()) break;
            System.out.println("  [ERROR] Name cannot be empty. Try again.");
        }

        // --- price ---
        BigDecimal price;
        while (true) {
            System.out.print("Enter price (Rs.): ");
            String raw = sc.nextLine().trim();
            try {
                price = new BigDecimal(raw);
                if (price.compareTo(BigDecimal.ZERO) > 0) break;
                System.out.println("  [ERROR] Price must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Invalid number. Enter a valid price.");
            }
        }

        // --- quantity ---
        int qty;
        while (true) {
            System.out.print("Enter available quantity: ");
            String raw = sc.nextLine().trim();
            try {
                qty = Integer.parseInt(raw);
                if (qty >= 0) break;
                System.out.println("  [ERROR] Quantity cannot be negative.");
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Invalid number. Enter a whole number.");
            }
        }

        try {
            int id = foodDAO.addFoodItem(name, price, qty);
            if (id > 0) {
                System.out.println("\n  [SUCCESS] Food item added with ID = " + id);
            } else {
                System.out.println("  [ERROR] Failed to add food item.");
            }
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
        }
    }

    // ================================================================== //
    //  FEATURE B — Display Food Menu
    // ================================================================== //

    public void displayFoodMenu() {
        System.out.println("\n--- FOOD MENU ---");
        try {
            List<FoodItem> items = foodDAO.getAllFoodItems();
            if (items.isEmpty()) {
                System.out.println("  No food items found. Add some items first.");
                return;
            }
            printMenuTable(items);
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
        }
    }

    private void printMenuTable(List<FoodItem> items) {
        String hr = "+------+---------------------------+------------+----------+----------------+";
        System.out.println(hr);
        System.out.printf("| %-4s | %-25s | %-10s | %-8s | %-14s |%n",
                "ID", "Food Name", "Price(Rs.)", "Qty", "Status");
        System.out.println(hr);
        for (FoodItem item : items) {
            String status = item.getQuantityAvailable() > 0 ? "Available" : "OUT OF STOCK";
            System.out.printf("| %-4d | %-25s | %10.2f | %-8d | %-14s |%n",
                    item.getFoodId(),
                    item.getFoodName(),
                    item.getPrice(),
                    item.getQuantityAvailable(),
                    status);
        }
        System.out.println(hr);
    }

    // ================================================================== //
    //  FEATURE C + D — Take Order & Calculate Bill
    // ================================================================== //

    public void takeOrder(Scanner sc) {
        System.out.println("\n--- TAKE CUSTOMER ORDER ---");

        // Show menu first
        List<FoodItem> menuItems;
        try {
            menuItems = foodDAO.getAllFoodItems();
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] Could not load menu: " + e.getMessage());
            return;
        }

        if (menuItems.isEmpty()) {
            System.out.println("  No food items available. Please add items first.");
            return;
        }
        printMenuTable(menuItems);

        List<OrderDetail> cartDetails = new ArrayList<>();

        // Build an in-memory map for quick lookup during cart building
        java.util.Map<Integer, FoodItem> menuMap = new java.util.LinkedHashMap<>();
        for (FoodItem fi : menuItems) menuMap.put(fi.getFoodId(), fi);

        // Track how much stock we are committing in this order (before DB update)
        java.util.Map<Integer, Integer> reservedQty = new java.util.LinkedHashMap<>();

        while (true) {
            System.out.print("\nEnter Food ID to add (or 0 to finish): ");
            String raw = sc.nextLine().trim();
            int foodId;
            try {
                foodId = Integer.parseInt(raw);
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Enter a valid number.");
                continue;
            }

            if (foodId == 0) {
                if (cartDetails.isEmpty()) {
                    System.out.println("  [ERROR] Order is empty. Add at least one item.");
                    continue;
                }
                break;
            }

            FoodItem selected = menuMap.get(foodId);
            if (selected == null) {
                System.out.println("  [ERROR] Food ID " + foodId + " does not exist.");
                continue;
            }

            // Already-reserved units for this item in current cart
            int alreadyReserved = reservedQty.getOrDefault(foodId, 0);
            int effectiveStock   = selected.getQuantityAvailable() - alreadyReserved;

            if (effectiveStock <= 0) {
                System.out.println("  [ERROR] '" + selected.getFoodName() + "' is out of stock.");
                continue;
            }

            System.out.print("Enter quantity (max " + effectiveStock + "): ");
            int qty;
            try {
                qty = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Enter a valid quantity.");
                continue;
            }

            if (qty <= 0) {
                System.out.println("  [ERROR] Quantity must be at least 1.");
                continue;
            }
            if (qty > effectiveStock) {
                System.out.println("  [ERROR] Only " + effectiveStock + " unit(s) available.");
                continue;
            }

            BigDecimal subtotal = selected.getPrice().multiply(BigDecimal.valueOf(qty));

            // Merge with existing line if same food_id
            boolean merged = false;
            for (OrderDetail od : cartDetails) {
                if (od.getFoodId() == foodId) {
                    od.setQuantity(od.getQuantity() + qty);
                    od.setSubtotal(od.getSubtotal().add(subtotal));
                    merged = true;
                    break;
                }
            }
            if (!merged) {
                cartDetails.add(new OrderDetail(
                        foodId, selected.getFoodName(), qty,
                        selected.getPrice(), subtotal));
            }

            reservedQty.merge(foodId, qty, Integer::sum);
            System.out.printf("  Added: %s x%d = Rs.%.2f%n",
                    selected.getFoodName(), qty, subtotal);
        }

        // Preview cart
        printBill(cartDetails, -1, null);

        System.out.print("\nConfirm order? (y/n): ");
        String confirm = sc.nextLine().trim().toLowerCase();
        if (!confirm.equals("y")) {
            System.out.println("  Order cancelled.");
            return;
        }

        // Persist using transaction
        try {
            Order saved = orderDAO.createOrder(cartDetails);
            System.out.println("\n  [SUCCESS] Order placed! Order ID = " + saved.getOrderId());
            printBill(saved.getDetails(), saved.getOrderId(), saved.getTotalAmount());
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] Order failed & rolled back: " + e.getMessage());
        }
    }

    /** Prints a formatted bill. Pass orderId = -1 for a preview (before saving). */
    public void printBill(List<OrderDetail> details, int orderId, BigDecimal grandTotal) {
        System.out.println();
        String hr = "+--+---------------------------+------+-----------+-----------+";
        System.out.println(hr);
        if (orderId > 0) {
            System.out.printf("|  BILL  -  Order #%-40d |%n", orderId);
            System.out.println(hr);
        } else {
            System.out.printf("|  BILL PREVIEW%-46s |%n", "");
            System.out.println(hr);
        }
        System.out.printf("| %-2s | %-25s | %-4s | %-9s | %-9s |%n",
                "#", "Item", "Qty", "Unit Price", "Subtotal");
        System.out.println(hr);

        BigDecimal total = BigDecimal.ZERO;
        int i = 1;
        for (OrderDetail d : details) {
            System.out.printf("| %-2d | %-25s | %-4d | Rs.%6.2f | Rs.%6.2f |%n",
                    i++, d.getFoodName(), d.getQuantity(),
                    d.getUnitPrice(), d.getSubtotal());
            total = total.add(d.getSubtotal());
        }
        System.out.println(hr);
        if (grandTotal != null) total = grandTotal;
        System.out.printf("|  GRAND TOTAL%-47s Rs.%8.2f |%n", "", total);
        System.out.println(hr);
    }

    // ================================================================== //
    //  FEATURE E — View Order History
    // ================================================================== //

    public void viewOrderHistory() {
        System.out.println("\n--- ORDER HISTORY ---");
        try {
            List<Order> orders = orderDAO.getAllOrders();
            if (orders.isEmpty()) {
                System.out.println("  No orders placed yet.");
                return;
            }
            String hr = "+----------+---------------------+----------------+";
            System.out.println(hr);
            System.out.printf("| %-8s | %-19s | %-14s |%n",
                    "Order ID", "Date & Time", "Total (Rs.)");
            System.out.println(hr);
            for (Order o : orders) {
                System.out.printf("| %-8d | %-19s | %14.2f |%n",
                        o.getOrderId(),
                        o.getOrderDate().format(DT_FMT),
                        o.getTotalAmount());
            }
            System.out.println(hr);
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
        }
    }

    // ================================================================== //
    //  FEATURE — View Order Details for a specific order
    // ================================================================== //

    public void viewOrderDetails(Scanner sc) {
        System.out.println("\n--- VIEW ORDER DETAILS ---");
        System.out.print("Enter Order ID: ");
        int orderId;
        try {
            orderId = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [ERROR] Invalid Order ID.");
            return;
        }

        try {
            Order header = orderDAO.getOrderById(orderId);
            if (header == null) {
                System.out.println("  [ERROR] Order ID " + orderId + " not found.");
                return;
            }
            List<OrderDetail> details = orderDAO.getOrderDetails(orderId);
            System.out.println("\n  Order Date : " + header.getOrderDate().format(DT_FMT));
            printBill(details, orderId, header.getTotalAmount());
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
        }
    }

    // ================================================================== //
    //  FEATURE — Update Food Item
    // ================================================================== //

    /**
     * Lets the admin pick a food item and choose which field to update:
     * (1) Food Name, (2) Price, (3) Quantity Available.
     */
    public void updateFoodItem(Scanner sc) {
        System.out.println("\n--- UPDATE FOOD ITEM ---");

        // Show current menu so user can pick an ID
        displayFoodMenu();

        // --- pick food ID ---
        int foodId = readInt(sc, "Enter Food ID to update (or 0 to cancel): ");
        if (foodId == 0) { System.out.println("  Update cancelled."); return; }

        FoodItem item;
        try {
            item = foodDAO.getFoodItemById(foodId);
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
            return;
        }

        if (item == null) {
            System.out.println("  [ERROR] Food ID " + foodId + " not found.");
            return;
        }

        System.out.println("\n  Current details:");
        System.out.printf("    Name     : %s%n", item.getFoodName());
        System.out.printf("    Price    : Rs.%.2f%n", item.getPrice());
        System.out.printf("    Quantity : %d%n", item.getQuantityAvailable());

        // --- sub-menu ---
        System.out.println("\n  What would you like to update?");
        System.out.println("    1. Food Name");
        System.out.println("    2. Price");
        System.out.println("    3. Quantity Available");
        System.out.println("    0. Cancel");
        int sub = readInt(sc, "  Enter choice: ");

        try {
            switch (sub) {
                case 1 -> {
                    // Update name
                    String newName;
                    while (true) {
                        System.out.print("  Enter new name: ");
                        newName = sc.nextLine().trim();
                        if (!newName.isEmpty()) break;
                        System.out.println("  [ERROR] Name cannot be empty.");
                    }
                    if (foodDAO.updateFoodName(foodId, newName)) {
                        System.out.println("  [SUCCESS] Name updated to: " + newName);
                    } else {
                        System.out.println("  [ERROR] Update failed (ID not found).");
                    }
                }
                case 2 -> {
                    // Update price
                    BigDecimal newPrice;
                    while (true) {
                        System.out.print("  Enter new price (Rs.): ");
                        String raw = sc.nextLine().trim();
                        try {
                            newPrice = new BigDecimal(raw);
                            if (newPrice.compareTo(BigDecimal.ZERO) > 0) break;
                            System.out.println("  [ERROR] Price must be > 0.");
                        } catch (NumberFormatException e) {
                            System.out.println("  [ERROR] Invalid number.");
                        }
                    }
                    if (foodDAO.updatePrice(foodId, newPrice)) {
                        System.out.printf("  [SUCCESS] Price updated to Rs.%.2f%n", newPrice);
                    } else {
                        System.out.println("  [ERROR] Update failed (ID not found).");
                    }
                }
                case 3 -> {
                    // Update quantity
                    int newQty;
                    while (true) {
                        System.out.print("  Enter new quantity: ");
                        String raw = sc.nextLine().trim();
                        try {
                            newQty = Integer.parseInt(raw);
                            if (newQty >= 0) break;
                            System.out.println("  [ERROR] Quantity cannot be negative.");
                        } catch (NumberFormatException e) {
                            System.out.println("  [ERROR] Invalid number.");
                        }
                    }
                    if (foodDAO.updateQuantity(foodId, newQty)) {
                        System.out.println("  [SUCCESS] Quantity updated to: " + newQty);
                    } else {
                        System.out.println("  [ERROR] Update failed (ID not found).");
                    }
                }
                case 0 -> System.out.println("  Update cancelled.");
                default -> System.out.println("  [ERROR] Invalid choice.");
            }
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
        }
    }

    // ================================================================== //
    //  FEATURE — Delete Food Item
    // ================================================================== //

    /**
     * Deletes a food item permanently.
     * If the item has been ordered (FK constraint), offers to set qty=0 instead
     * so it shows as OUT OF STOCK without breaking historical order records.
     */
    public void deleteFoodItem(Scanner sc) {
        System.out.println("\n--- DELETE FOOD ITEM ---");
        displayFoodMenu();

        int foodId = readInt(sc, "Enter Food ID to delete (or 0 to cancel): ");
        if (foodId == 0) { System.out.println("  Delete cancelled."); return; }

        FoodItem item;
        try {
            item = foodDAO.getFoodItemById(foodId);
        } catch (SQLException e) {
            System.out.println("  [DB ERROR] " + e.getMessage());
            return;
        }

        if (item == null) {
            System.out.println("  [ERROR] Food ID " + foodId + " not found.");
            return;
        }

        System.out.printf("%n  You are about to delete: [%d] %s (Rs.%.2f, Qty:%d)%n",
                item.getFoodId(), item.getFoodName(),
                item.getPrice(), item.getQuantityAvailable());
        System.out.print("  Confirm delete? (y/n): ");
        String confirm = sc.nextLine().trim().toLowerCase();

        if (!confirm.equals("y")) {
            System.out.println("  Delete cancelled.");
            return;
        }

        try {
            boolean deleted = foodDAO.deleteFoodItem(foodId);
            if (deleted) {
                System.out.println("  [SUCCESS] Food item deleted successfully.");
            } else {
                System.out.println("  [ERROR] Delete failed — Food ID not found.");
            }
        } catch (SQLException e) {
            // FK constraint means this item is referenced in Order_Details
            String msg = e.getMessage() != null ? e.getMessage().toLowerCase() : "";
            if (msg.contains("foreign key") || msg.contains("constraint")) {
                System.out.println("\n  [INFO] Cannot delete — this item appears in existing orders.");
                System.out.println("         To hide it from the menu, set its quantity to 0.");
                System.out.print("  Set quantity to 0 (mark as OUT OF STOCK)? (y/n): ");
                String fallback = sc.nextLine().trim().toLowerCase();
                if (fallback.equals("y")) {
                    try {
                        foodDAO.updateQuantity(foodId, 0);
                        System.out.println("  [SUCCESS] Quantity set to 0 — item now shows as OUT OF STOCK.");
                    } catch (SQLException ex) {
                        System.out.println("  [DB ERROR] " + ex.getMessage());
                    }
                } else {
                    System.out.println("  No changes made.");
                }
            } else {
                System.out.println("  [DB ERROR] " + e.getMessage());
            }
        }
    }

    // ================================================================== //
    //  HELPER — read a validated integer from the Scanner
    // ================================================================== //

    private int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String raw = sc.nextLine().trim();
            try {
                return Integer.parseInt(raw);
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Please enter a whole number.");
            }
        }
    }
}
