package canteen;

import java.math.BigDecimal;

/**
 * Model class representing one row in the Food_Items table.
 */
public class FoodItem {

    private int        foodId;
    private String     foodName;
    private BigDecimal price;
    private int        quantityAvailable;

    // ------------------------------------------------------------------ //
    // Constructors
    // ------------------------------------------------------------------ //

    public FoodItem() {}

    public FoodItem(int foodId, String foodName, BigDecimal price, int quantityAvailable) {
        this.foodId            = foodId;
        this.foodName          = foodName;
        this.price             = price;
        this.quantityAvailable = quantityAvailable;
    }

    // ------------------------------------------------------------------ //
    // Getters & Setters
    // ------------------------------------------------------------------ //

    public int getFoodId()                   { return foodId; }
    public void setFoodId(int foodId)        { this.foodId = foodId; }

    public String getFoodName()              { return foodName; }
    public void setFoodName(String foodName) { this.foodName = foodName; }

    public BigDecimal getPrice()             { return price; }
    public void setPrice(BigDecimal price)   { this.price = price; }

    public int getQuantityAvailable()                    { return quantityAvailable; }
    public void setQuantityAvailable(int quantityAvailable) {
        this.quantityAvailable = quantityAvailable;
    }

    @Override
    public String toString() {
        String status = quantityAvailable > 0 ? "" : "  [OUT OF STOCK]";
        return String.format("ID:%-4d  %-25s  Rs.%-10.2f  Qty:%-5d%s",
                foodId, foodName, price, quantityAvailable, status);
    }
}
