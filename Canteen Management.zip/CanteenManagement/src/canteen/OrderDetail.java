package canteen;

import java.math.BigDecimal;

/**
 * Model class representing one row in the Order_Details table.
 */
public class OrderDetail {

    private int        detailId;
    private int        orderId;
    private int        foodId;
    private String     foodName;   // joined from Food_Items for display
    private int        quantity;
    private BigDecimal unitPrice;
    private BigDecimal subtotal;

    // ------------------------------------------------------------------ //
    // Constructors
    // ------------------------------------------------------------------ //

    public OrderDetail() {}

    public OrderDetail(int foodId, String foodName, int quantity,
                       BigDecimal unitPrice, BigDecimal subtotal) {
        this.foodId    = foodId;
        this.foodName  = foodName;
        this.quantity  = quantity;
        this.unitPrice = unitPrice;
        this.subtotal  = subtotal;
    }

    // ------------------------------------------------------------------ //
    // Getters & Setters
    // ------------------------------------------------------------------ //

    public int getDetailId()                    { return detailId; }
    public void setDetailId(int detailId)       { this.detailId = detailId; }

    public int getOrderId()                     { return orderId; }
    public void setOrderId(int orderId)         { this.orderId = orderId; }

    public int getFoodId()                      { return foodId; }
    public void setFoodId(int foodId)           { this.foodId = foodId; }

    public String getFoodName()                 { return foodName; }
    public void setFoodName(String foodName)    { this.foodName = foodName; }

    public int getQuantity()                    { return quantity; }
    public void setQuantity(int quantity)       { this.quantity = quantity; }

    public BigDecimal getUnitPrice()            { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice){ this.unitPrice = unitPrice; }

    public BigDecimal getSubtotal()             { return subtotal; }
    public void setSubtotal(BigDecimal subtotal){ this.subtotal = subtotal; }
}
