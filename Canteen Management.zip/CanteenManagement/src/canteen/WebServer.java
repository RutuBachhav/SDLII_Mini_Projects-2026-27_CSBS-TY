package canteen;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Built-in HTTP Web Server for Canteen Management System.
 * Accessible on http://localhost:8080/
 */
public class WebServer {

    private static final int PORT = 8080;
    private static final FoodDAO foodDAO = new FoodDAO();
    private static final OrderDAO orderDAO = new OrderDAO();
    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss");

    public static void main(String[] args) {
        int port = PORT;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {}
        }
        startServer(port);
    }

    public static void startServer(int preferredPort) {
        HttpServer server = null;
        int port = preferredPort;
        while (server == null && port < preferredPort + 10) {
            try {
                server = HttpServer.create(new InetSocketAddress(port), 0);
            } catch (IOException e) {
                port++;
            }
        }

        if (server == null) {
            System.err.println("[SERVER ERROR] Could not find an open port starting from " + preferredPort);
            return;
        }

        try {
            server.createContext("/", new RootHandler());
            server.createContext("/api/menu", new MenuHandler());
            server.createContext("/api/order", new PlaceOrderHandler());
            server.createContext("/api/food/add", new AddFoodHandler());
            server.createContext("/api/food/update", new UpdateFoodHandler());
            server.createContext("/api/food/delete", new DeleteFoodHandler());
            server.createContext("/api/orders", new OrdersHandler());
            server.createContext("/api/order/details", new OrderDetailsHandler());

            server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
            server.start();
            System.out.println("==================================================================");
            System.out.println("  CANTEEN MANAGEMENT SYSTEM - WEB SERVER RUNNING");
            System.out.println("  Local URL: http://localhost:" + port + "/");
            System.out.println("==================================================================");
        } catch (Exception e) {
            System.err.println("[SERVER ERROR] Failed to initialize server: " + e.getMessage());
        }
    }

    private static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestURI().getPath().equals("/")) {
                exchange.sendResponseHeaders(404, -1);
                return;
            }
            String html = getHtmlPage();
            byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    private static class MenuHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                List<FoodItem> items = foodDAO.getAllFoodItems();
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < items.size(); i++) {
                    FoodItem f = items.get(i);
                    sb.append(String.format("{\"id\":%d,\"name\":\"%s\",\"price\":%.2f,\"quantity\":%d}",
                            f.getFoodId(), escapeJson(f.getFoodName()), f.getPrice(), f.getQuantityAvailable()));
                    if (i < items.size() - 1) sb.append(",");
                }
                sb.append("]");
                sendJson(exchange, 200, sb.toString());
            } catch (SQLException e) {
                sendJson(exchange, 500, "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class PlaceOrderHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            Map<String, String> params = parseFormData(exchange);
            // Expected format: items=id:qty,id:qty
            String itemsParam = params.get("items");
            if (itemsParam == null || itemsParam.trim().isEmpty()) {
                sendJson(exchange, 400, "{\"success\":false,\"message\":\"No items in cart\"}");
                return;
            }

            try {
                List<FoodItem> menu = foodDAO.getAllFoodItems();
                Map<Integer, FoodItem> menuMap = new HashMap<>();
                for (FoodItem fi : menu) menuMap.put(fi.getFoodId(), fi);

                List<OrderDetail> details = new ArrayList<>();
                String[] itemPairs = itemsParam.split(",");
                for (String pair : itemPairs) {
                    String[] parts = pair.trim().split(":");
                    if (parts.length != 2) continue;
                    int foodId = Integer.parseInt(parts[0].trim());
                    int qty = Integer.parseInt(parts[1].trim());
                    if (qty <= 0) continue;

                    FoodItem fi = menuMap.get(foodId);
                    if (fi == null) {
                        sendJson(exchange, 400, "{\"success\":false,\"message\":\"Invalid Food ID: " + foodId + "\"}");
                        return;
                    }
                    if (fi.getQuantityAvailable() < qty) {
                        sendJson(exchange, 400, "{\"success\":false,\"message\":\"Insufficient stock for " + fi.getFoodName() + "\"}");
                        return;
                    }
                    BigDecimal subtotal = fi.getPrice().multiply(BigDecimal.valueOf(qty));
                    details.add(new OrderDetail(foodId, fi.getFoodName(), qty, fi.getPrice(), subtotal));
                }

                if (details.isEmpty()) {
                    sendJson(exchange, 400, "{\"success\":false,\"message\":\"Cart is empty\"}");
                    return;
                }

                Order order = orderDAO.createOrder(details);
                sendJson(exchange, 200, "{\"success\":true,\"orderId\":" + order.getOrderId() + ",\"total\":" + order.getTotalAmount() + "}");
            } catch (Exception e) {
                sendJson(exchange, 500, "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class AddFoodHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            Map<String, String> params = parseFormData(exchange);
            String name = params.get("name");
            String priceStr = params.get("price");
            String qtyStr = params.get("quantity");

            if (name == null || name.trim().isEmpty() || priceStr == null || qtyStr == null) {
                sendJson(exchange, 400, "{\"success\":false,\"message\":\"All fields are required\"}");
                return;
            }

            try {
                BigDecimal price = new BigDecimal(priceStr.trim());
                int qty = Integer.parseInt(qtyStr.trim());
                if (price.compareTo(BigDecimal.ZERO) <= 0 || qty < 0) {
                    sendJson(exchange, 400, "{\"success\":false,\"message\":\"Invalid price or quantity\"}");
                    return;
                }
                int newId = foodDAO.addFoodItem(name.trim(), price, qty);
                sendJson(exchange, 200, "{\"success\":true,\"foodId\":" + newId + "}");
            } catch (Exception e) {
                sendJson(exchange, 500, "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class UpdateFoodHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            Map<String, String> params = parseFormData(exchange);
            try {
                int foodId = Integer.parseInt(params.get("foodId"));
                String field = params.get("field");
                String value = params.get("value");

                boolean ok = false;
                if ("name".equalsIgnoreCase(field)) {
                    if (value == null || value.trim().isEmpty()) {
                        sendJson(exchange, 400, "{\"success\":false,\"message\":\"Name cannot be empty\"}");
                        return;
                    }
                    ok = foodDAO.updateFoodName(foodId, value.trim());
                } else if ("price".equalsIgnoreCase(field)) {
                    BigDecimal price = new BigDecimal(value.trim());
                    if (price.compareTo(BigDecimal.ZERO) <= 0) {
                        sendJson(exchange, 400, "{\"success\":false,\"message\":\"Price must be > 0\"}");
                        return;
                    }
                    ok = foodDAO.updatePrice(foodId, price);
                } else if ("quantity".equalsIgnoreCase(field)) {
                    int qty = Integer.parseInt(value.trim());
                    if (qty < 0) {
                        sendJson(exchange, 400, "{\"success\":false,\"message\":\"Quantity cannot be negative\"}");
                        return;
                    }
                    ok = foodDAO.updateQuantity(foodId, qty);
                }
                sendJson(exchange, 200, "{\"success\":" + ok + "}");
            } catch (Exception e) {
                sendJson(exchange, 500, "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class DeleteFoodHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            Map<String, String> params = parseFormData(exchange);
            try {
                int foodId = Integer.parseInt(params.get("foodId"));
                try {
                    boolean deleted = foodDAO.deleteFoodItem(foodId);
                    sendJson(exchange, 200, "{\"success\":" + deleted + ",\"deleted\":true}");
                } catch (SQLException ex) {
                    // Foreign key constraint: mark as out of stock
                    foodDAO.updateQuantity(foodId, 0);
                    sendJson(exchange, 200, "{\"success\":true,\"deleted\":false,\"message\":\"Item is referenced in past orders; marked as OUT OF STOCK.\"}");
                }
            } catch (Exception e) {
                sendJson(exchange, 500, "{\"success\":false,\"message\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class OrdersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                List<Order> orders = orderDAO.getAllOrders();
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < orders.size(); i++) {
                    Order o = orders.get(i);
                    sb.append(String.format("{\"id\":%d,\"date\":\"%s\",\"total\":%.2f}",
                            o.getOrderId(), o.getOrderDate().format(DT_FMT), o.getTotalAmount()));
                    if (i < orders.size() - 1) sb.append(",");
                }
                sb.append("]");
                sendJson(exchange, 200, sb.toString());
            } catch (SQLException e) {
                sendJson(exchange, 500, "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static class OrderDetailsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String query = exchange.getRequestURI().getQuery();
            int orderId = -1;
            if (query != null && query.startsWith("id=")) {
                try {
                    orderId = Integer.parseInt(query.substring(3).trim());
                } catch (NumberFormatException ignored) {}
            }
            if (orderId <= 0) {
                sendJson(exchange, 400, "{\"error\":\"Invalid order ID\"}");
                return;
            }

            try {
                Order header = orderDAO.getOrderById(orderId);
                if (header == null) {
                    sendJson(exchange, 404, "{\"error\":\"Order not found\"}");
                    return;
                }
                List<OrderDetail> details = orderDAO.getOrderDetails(orderId);
                StringBuilder sb = new StringBuilder("{");
                sb.append(String.format("\"id\":%d,\"date\":\"%s\",\"total\":%.2f,\"items\":[",
                        header.getOrderId(), header.getOrderDate().format(DT_FMT), header.getTotalAmount()));
                for (int i = 0; i < details.size(); i++) {
                    OrderDetail d = details.get(i);
                    sb.append(String.format("{\"name\":\"%s\",\"qty\":%d,\"price\":%.2f,\"subtotal\":%.2f}",
                            escapeJson(d.getFoodName()), d.getQuantity(), d.getUnitPrice(), d.getSubtotal()));
                    if (i < details.size() - 1) sb.append(",");
                }
                sb.append("]}");
                sendJson(exchange, 200, sb.toString());
            } catch (SQLException e) {
                sendJson(exchange, 500, "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
            }
        }
    }

    private static Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len;
        while ((len = is.read(buffer)) != -1) {
            baos.write(buffer, 0, len);
        }
        String body = baos.toString(StandardCharsets.UTF_8);
        Map<String, String> map = new HashMap<>();
        if (body.isEmpty()) return map;

        String[] pairs = body.split("&");
        for (String pair : pairs) {
            int idx = pair.indexOf("=");
            if (idx > 0) {
                String key = URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8);
                String val = URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8);
                map.put(key, val);
            }
        }
        return map;
    }

    private static void sendJson(HttpExchange exchange, int code, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private static String getHtmlPage() {
        return "<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<head>\n" +
"    <meta charset=\"UTF-8\">\n" +
"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
"    <title>Canteen Management System</title>\n" +
"    <link href=\"https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap\" rel=\"stylesheet\">\n" +
"    <style>\n" +
"        :root {\n" +
"            --primary: #4f46e5;\n" +
"            --primary-hover: #4338ca;\n" +
"            --success: #10b981;\n" +
"            --danger: #ef4444;\n" +
"            --dark: #1e293b;\n" +
"            --card-bg: #ffffff;\n" +
"            --bg: #f8fafc;\n" +
"            --border: #e2e8f0;\n" +
"        }\n" +
"        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }\n" +
"        body { background: var(--bg); color: #334155; min-height: 100vh; display: flex; flex-direction: column; }\n" +
"        header {\n" +
"            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);\n" +
"            color: white;\n" +
"            padding: 24px 32px;\n" +
"            box-shadow: 0 4px 15px rgba(79, 70, 229, 0.2);\n" +
"            display: flex;\n" +
"            justify-content: space-between;\n" +
"            align-items: center;\n" +
"        }\n" +
"        header h1 { font-size: 24px; font-weight: 700; letter-spacing: -0.5px; display: flex; align-items: center; gap: 10px; }\n" +
"        .badge { background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 400; }\n" +
"        nav {\n" +
"            background: white;\n" +
"            border-bottom: 1px solid var(--border);\n" +
"            padding: 0 32px;\n" +
"            display: flex;\n" +
"            gap: 24px;\n" +
"        }\n" +
"        .tab-btn {\n" +
"            background: none;\n" +
"            border: none;\n" +
"            padding: 16px 8px;\n" +
"            font-size: 15px;\n" +
"            font-weight: 500;\n" +
"            color: #64748b;\n" +
"            cursor: pointer;\n" +
"            border-bottom: 3px solid transparent;\n" +
"            transition: all 0.2s;\n" +
"        }\n" +
"        .tab-btn:hover { color: var(--primary); }\n" +
"        .tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); font-weight: 600; }\n" +
"        main { padding: 32px; flex: 1; max-width: 1400px; width: 100%; margin: 0 auto; }\n" +
"        .tab-content { display: none; }\n" +
"        .tab-content.active { display: block; animation: fadeIn 0.3s ease; }\n" +
"        @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }\n" +
"        \n" +
"        /* Menu and Cart Grid */\n" +
"        .order-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 28px; }\n" +
"        @media(max-width: 900px) { .order-layout { grid-template-columns: 1fr; } }\n" +
"        \n" +
"        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 20px; }\n" +
"        .card {\n" +
"            background: var(--card-bg);\n" +
"            border-radius: 12px;\n" +
"            padding: 20px;\n" +
"            border: 1px solid var(--border);\n" +
"            box-shadow: 0 2px 8px rgba(0,0,0,0.04);\n" +
"            transition: transform 0.2s, box-shadow 0.2s;\n" +
"            display: flex;\n" +
"            flex-direction: column;\n" +
"            justify-content: space-between;\n" +
"        }\n" +
"        .card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); }\n" +
"        .card.out-of-stock { opacity: 0.6; filter: grayscale(40%); }\n" +
"        .card h3 { font-size: 17px; font-weight: 600; margin-bottom: 8px; color: var(--dark); }\n" +
"        .card-price { font-size: 18px; font-weight: 700; color: var(--primary); margin-bottom: 6px; }\n" +
"        .card-stock { font-size: 13px; color: #64748b; margin-bottom: 16px; display: flex; align-items: center; gap: 6px; }\n" +
"        .stock-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--success); }\n" +
"        .card.out-of-stock .stock-dot { background: var(--danger); }\n" +
"        \n" +
"        .btn {\n" +
"            background: var(--primary);\n" +
"            color: white;\n" +
"            border: none;\n" +
"            padding: 10px 18px;\n" +
"            border-radius: 8px;\n" +
"            font-size: 14px;\n" +
"            font-weight: 500;\n" +
"            cursor: pointer;\n" +
"            transition: all 0.2s;\n" +
"            display: inline-flex;\n" +
"            align-items: center;\n" +
"            justify-content: center;\n" +
"            gap: 8px;\n" +
"        }\n" +
"        .btn:hover { background: var(--primary-hover); }\n" +
"        .btn:disabled { background: #cbd5e1; cursor: not-allowed; }\n" +
"        .btn-success { background: var(--success); }\n" +
"        .btn-success:hover { background: #059669; }\n" +
"        .btn-danger { background: var(--danger); }\n" +
"        .btn-danger:hover { background: #dc2626; }\n" +
"        .btn-sm { padding: 6px 12px; font-size: 12px; border-radius: 6px; }\n" +
"        \n" +
"        /* Cart Panel */\n" +
"        .cart-panel {\n" +
"            background: white;\n" +
"            border-radius: 12px;\n" +
"            border: 1px solid var(--border);\n" +
"            padding: 24px;\n" +
"            box-shadow: 0 4px 15px rgba(0,0,0,0.05);\n" +
"            position: sticky;\n" +
"            top: 24px;\n" +
"            display: flex;\n" +
"            flex-direction: column;\n" +
"            max-height: calc(100vh - 150px);\n" +
"        }\n" +
"        .cart-panel h2 { font-size: 18px; font-weight: 600; margin-bottom: 16px; border-bottom: 1px solid var(--border); padding-bottom: 12px; }\n" +
"        .cart-items { flex: 1; overflow-y: auto; margin-bottom: 16px; display: flex; flex-direction: column; gap: 12px; }\n" +
"        .cart-item {\n" +
"            display: flex;\n" +
"            justify-content: space-between;\n" +
"            align-items: center;\n" +
"            padding-bottom: 10px;\n" +
"            border-bottom: 1px dashed var(--border);\n" +
"        }\n" +
"        .cart-item-title { font-weight: 500; font-size: 14px; }\n" +
"        .cart-item-sub { font-size: 12px; color: #64748b; }\n" +
"        .cart-qty-ctrl { display: flex; align-items: center; gap: 8px; }\n" +
"        .cart-qty-btn { width: 26px; height: 26px; border-radius: 6px; border: 1px solid var(--border); background: #f1f5f9; cursor: pointer; font-weight: 600; }\n" +
"        .cart-total-box { border-top: 2px solid var(--border); padding-top: 14px; margin-bottom: 16px; display: flex; justify-content: space-between; font-size: 18px; font-weight: 700; color: var(--dark); }\n" +
"        \n" +
"        /* Tables */\n" +
"        .table-container { background: white; border-radius: 12px; border: 1px solid var(--border); overflow-x: auto; }\n" +
"        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }\n" +
"        th { background: #f8fafc; padding: 14px 20px; font-weight: 600; color: #475569; border-bottom: 1px solid var(--border); }\n" +
"        td { padding: 14px 20px; border-bottom: 1px solid var(--border); color: #334155; }\n" +
"        tr:last-child td { border-bottom: none; }\n" +
"        tr:hover td { background: #f8fafc; }\n" +
"        \n" +
"        /* Form */\n" +
"        .form-card {\n" +
"            background: white;\n" +
"            border-radius: 12px;\n" +
"            border: 1px solid var(--border);\n" +
"            padding: 32px;\n" +
"            max-width: 600px;\n" +
"            margin: 0 auto;\n" +
"            box-shadow: 0 4px 15px rgba(0,0,0,0.04);\n" +
"        }\n" +
"        .form-group { margin-bottom: 20px; }\n" +
"        .form-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: #475569; }\n" +
"        .form-control {\n" +
"            width: 100%;\n" +
"            padding: 12px 14px;\n" +
"            border-radius: 8px;\n" +
"            border: 1px solid var(--border);\n" +
"            font-size: 14px;\n" +
"            outline: none;\n" +
"            transition: border 0.2s;\n" +
"        }\n" +
"        .form-control:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }\n" +
"        \n" +
"        /* Modal */\n" +
"        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); align-items: center; justify-content: center; z-index: 100; }\n" +
"        .modal.active { display: flex; }\n" +
"        .modal-box { background: white; border-radius: 16px; width: 90%; max-width: 550px; padding: 28px; box-shadow: 0 20px 40px rgba(0,0,0,0.2); animation: popIn 0.25s ease; }\n" +
"        @keyframes popIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }\n" +
"        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border); }\n" +
"        .modal-close { background: none; border: none; font-size: 24px; cursor: pointer; color: #64748b; }\n" +
"        \n" +
"        .toast { position: fixed; bottom: 24px; right: 24px; background: #1e293b; color: white; padding: 14px 24px; border-radius: 10px; font-size: 14px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); display: none; z-index: 200; }\n" +
"        .toast.show { display: block; animation: slideUp 0.3s ease; }\n" +
"        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }\n" +
"    </style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"    <header>\n" +
"        <h1>🍽️ Canteen Management System <span class=\"badge\">MySQL + JDBC</span></h1>\n" +
"        <div style=\"font-size: 13px; opacity: 0.9;\">Connected to <strong>canteen_db</strong></div>\n" +
"    </header>\n" +
"\n" +
"    <nav>\n" +
"        <button class=\"tab-btn active\" onclick=\"switchTab('orderTab')\">Order Food</button>\n" +
"        <button class=\"tab-btn\" onclick=\"switchTab('manageTab')\">Manage Menu & Stock</button>\n" +
"        <button class=\"tab-btn\" onclick=\"switchTab('addTab')\">Add New Item</button>\n" +
"        <button class=\"tab-btn\" onclick=\"switchTab('historyTab')\">Order History</button>\n" +
"    </nav>\n" +
"\n" +
"    <main>\n" +
"        <!-- TAB 1: ORDER FOOD -->\n" +
"        <div id=\"orderTab\" class=\"tab-content active\">\n" +
"            <div class=\"order-layout\">\n" +
"                <div>\n" +
"                    <h2 style=\"margin-bottom: 18px; font-size: 20px;\">Available Food Menu</h2>\n" +
"                    <div id=\"menuGrid\" class=\"grid\">Loading menu...</div>\n" +
"                </div>\n" +
"                <div>\n" +
"                    <div class=\"cart-panel\">\n" +
"                        <h2>🛒 Your Cart</h2>\n" +
"                        <div id=\"cartItems\" class=\"cart-items\">\n" +
"                            <div style=\"text-align: center; color: #94a3b8; padding: 30px 0;\">Your cart is empty.<br>Click items from the menu to add.</div>\n" +
"                        </div>\n" +
"                        <div class=\"cart-total-box\">\n" +
"                            <span>Total Amount:</span>\n" +
"                            <span id=\"cartTotal\" style=\"color: var(--primary);\">Rs. 0.00</span>\n" +
"                        </div>\n" +
"                        <button id=\"placeOrderBtn\" class=\"btn btn-success\" style=\"width: 100%; padding: 14px; font-size: 16px;\" onclick=\"placeOrder()\" disabled>Place Order Now</button>\n" +
"                    </div>\n" +
"                </div>\n" +
"            </div>\n" +
"        </div>\n" +
"\n" +
"        <!-- TAB 2: MANAGE MENU -->\n" +
"        <div id=\"manageTab\" class=\"tab-content\">\n" +
"            <div style=\"display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;\">\n" +
"                <h2 style=\"font-size: 20px;\">Inventory & Menu Management</h2>\n" +
"                <button class=\"btn btn-sm\" onclick=\"loadManageMenu()\">🔄 Refresh</button>\n" +
"            </div>\n" +
"            <div class=\"table-container\">\n" +
"                <table>\n" +
"                    <thead>\n" +
"                        <tr>\n" +
"                            <th>ID</th>\n" +
"                            <th>Food Name</th>\n" +
"                            <th>Price (Rs.)</th>\n" +
"                            <th>Available Qty</th>\n" +
"                            <th>Status</th>\n" +
"                            <th>Actions</th>\n" +
"                        </tr>\n" +
"                    </thead>\n" +
"                    <tbody id=\"manageTableBody\"></tbody>\n" +
"                </table>\n" +
"            </div>\n" +
"        </div>\n" +
"\n" +
"        <!-- TAB 3: ADD ITEM -->\n" +
"        <div id=\"addTab\" class=\"tab-content\">\n" +
"            <div class=\"form-card\">\n" +
"                <h2 style=\"margin-bottom: 24px; font-size: 20px;\">➕ Add New Food Item</h2>\n" +
"                <form id=\"addFoodForm\" onsubmit=\"submitAddFood(event)\">\n" +
"                    <div class=\"form-group\">\n" +
"                        <label>Food Item Name</label>\n" +
"                        <input type=\"text\" id=\"foodName\" class=\"form-control\" placeholder=\"e.g., Paneer Butter Masala\" required>\n" +
"                    </div>\n" +
"                    <div class=\"form-group\">\n" +
"                        <label>Price (Rs.)</label>\n" +
"                        <input type=\"number\" step=\"0.5\" min=\"1\" id=\"foodPrice\" class=\"form-control\" placeholder=\"e.g., 80.00\" required>\n" +
"                    </div>\n" +
"                    <div class=\"form-group\">\n" +
"                        <label>Initial Available Quantity</label>\n" +
"                        <input type=\"number\" min=\"0\" id=\"foodQty\" class=\"form-control\" placeholder=\"e.g., 50\" required>\n" +
"                    </div>\n" +
"                    <button type=\"submit\" class=\"btn\" style=\"width: 100%; padding: 12px;\">Save to Database</button>\n" +
"                </form>\n" +
"            </div>\n" +
"        </div>\n" +
"\n" +
"        <!-- TAB 4: ORDER HISTORY -->\n" +
"        <div id=\"historyTab\" class=\"tab-content\">\n" +
"            <div style=\"display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;\">\n" +
"                <h2 style=\"font-size: 20px;\">📜 Past Orders</h2>\n" +
"                <button class=\"btn btn-sm\" onclick=\"loadOrders()\">🔄 Refresh</button>\n" +
"            </div>\n" +
"            <div class=\"table-container\">\n" +
"                <table>\n" +
"                    <thead>\n" +
"                        <tr>\n" +
"                            <th>Order ID</th>\n" +
"                            <th>Date & Time</th>\n" +
"                            <th>Total Amount (Rs.)</th>\n" +
"                            <th>Details</th>\n" +
"                        </tr>\n" +
"                    </thead>\n" +
"                    <tbody id=\"ordersTableBody\"></tbody>\n" +
"                </table>\n" +
"            </div>\n" +
"        </div>\n" +
"    </main>\n" +
"\n" +
"    <!-- Order Details / Bill Modal -->\n" +
"    <div id=\"billModal\" class=\"modal\">\n" +
"        <div class=\"modal-box\">\n" +
"            <div class=\"modal-header\">\n" +
"                <h3 id=\"modalTitle\">🧾 Order Receipt</h3>\n" +
"                <button class=\"modal-close\" onclick=\"closeModal()\">&times;</button>\n" +
"            </div>\n" +
"            <div id=\"modalBody\"></div>\n" +
"            <div style=\"margin-top: 24px; text-align: right;\">\n" +
"                <button class=\"btn\" onclick=\"closeModal()\">Close</button>\n" +
"            </div>\n" +
"        </div>\n" +
"    </div>\n" +
"\n" +
"    <div id=\"toast\" class=\"toast\"></div>\n" +
"\n" +
"    <script>\n" +
"        let menuData = [];\n" +
"        let cart = {}; // foodId -> qty\n" +
"\n" +
"        function showToast(msg) {\n" +
"            const t = document.getElementById('toast');\n" +
"            t.textContent = msg;\n" +
"            t.className = 'toast show';\n" +
"            setTimeout(() => { t.className = 'toast'; }, 3000);\n" +
"        }\n" +
"\n" +
"        function switchTab(tabId) {\n" +
"            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));\n" +
"            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));\n" +
"            event.target.classList.add('active');\n" +
"            document.getElementById(tabId).classList.add('active');\n" +
"            if (tabId === 'orderTab') loadMenu();\n" +
"            if (tabId === 'manageTab') loadManageMenu();\n" +
"            if (tabId === 'historyTab') loadOrders();\n" +
"        }\n" +
"\n" +
"        async function loadMenu() {\n" +
"            try {\n" +
"                const res = await fetch('/api/menu');\n" +
"                menuData = await res.json();\n" +
"                renderMenu();\n" +
"            } catch (e) { showToast('Error loading menu: ' + e); }\n" +
"        }\n" +
"\n" +
"        function renderMenu() {\n" +
"            const grid = document.getElementById('menuGrid');\n" +
"            if (menuData.length === 0) {\n" +
"                grid.innerHTML = '<div style=\"grid-column: 1/-1; text-align: center; color: #94a3b8; padding: 40px;\">No food items found. Go to \"Add New Item\" tab to add items.</div>';\n" +
"                return;\n" +
"            }\n" +
"            grid.innerHTML = menuData.map(item => {\n" +
"                const isOut = item.quantity <= 0;\n" +
"                return `\n" +
"                    <div class=\"card ${isOut ? 'out-of-stock' : ''}\">\n" +
"                        <div>\n" +
"                            <h3>${item.name}</h3>\n" +
"                            <div class=\"card-price\">Rs. ${item.price.toFixed(2)}</div>\n" +
"                            <div class=\"card-stock\">\n" +
"                                <span class=\"stock-dot\"></span>\n" +
"                                ${isOut ? '<strong style=\"color: var(--danger);\">OUT OF STOCK</strong>' : `Available: ${item.quantity}`}\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <button class=\"btn\" onclick=\"addToCart(${item.id})\" ${isOut ? 'disabled' : ''}>\n" +
"                            ${isOut ? 'Unavailable' : '➕ Add to Cart'}\n" +
"                        </button>\n" +
"                    </div>\n" +
"                `;\n" +
"            }).join('');\n" +
"        }\n" +
"\n" +
"        function addToCart(foodId) {\n" +
"            const item = menuData.find(i => i.id === foodId);\n" +
"            if (!item || item.quantity <= 0) return;\n" +
"            const curQty = cart[foodId] || 0;\n" +
"            if (curQty + 1 > item.quantity) {\n" +
"                showToast(`Cannot add more. Only ${item.quantity} available.`);\n" +
"                return;\n" +
"            }\n" +
"            cart[foodId] = curQty + 1;\n" +
"            renderCart();\n" +
"        }\n" +
"\n" +
"        function updateCartQty(foodId, delta) {\n" +
"            const item = menuData.find(i => i.id === foodId);\n" +
"            const curQty = cart[foodId] || 0;\n" +
"            const newQty = curQty + delta;\n" +
"            if (newQty <= 0) {\n" +
"                delete cart[foodId];\n" +
"            } else if (item && newQty > item.quantity) {\n" +
"                showToast(`Only ${item.quantity} units available.`);\n" +
"            } else {\n" +
"                cart[foodId] = newQty;\n" +
"            }\n" +
"            renderCart();\n" +
"        }\n" +
"\n" +
"        function renderCart() {\n" +
"            const cartBox = document.getElementById('cartItems');\n" +
"            const keys = Object.keys(cart);\n" +
"            if (keys.length === 0) {\n" +
"                cartBox.innerHTML = '<div style=\"text-align: center; color: #94a3b8; padding: 30px 0;\">Your cart is empty.<br>Click items from the menu to add.</div>';\n" +
"                document.getElementById('cartTotal').textContent = 'Rs. 0.00';\n" +
"                document.getElementById('placeOrderBtn').disabled = true;\n" +
"                return;\n" +
"            }\n" +
"\n" +
"            let total = 0;\n" +
"            cartBox.innerHTML = keys.map(id => {\n" +
"                const foodId = parseInt(id);\n" +
"                const item = menuData.find(i => i.id === foodId);\n" +
"                const qty = cart[id];\n" +
"                const subtotal = item.price * qty;\n" +
"                total += subtotal;\n" +
"                return `\n" +
"                    <div class=\"cart-item\">\n" +
"                        <div>\n" +
"                            <div class=\"cart-item-title\">${item.name}</div>\n" +
"                            <div class=\"cart-item-sub\">Rs. ${item.price.toFixed(2)} × ${qty} = <strong>Rs. ${subtotal.toFixed(2)}</strong></div>\n" +
"                        </div>\n" +
"                        <div class=\"cart-qty-ctrl\">\n" +
"                            <button class=\"cart-qty-btn\" onclick=\"updateCartQty(${foodId}, -1)\">-</button>\n" +
"                            <span style=\"font-size: 13px; font-weight: 600;\">${qty}</span>\n" +
"                            <button class=\"cart-qty-btn\" onclick=\"updateCartQty(${foodId}, 1)\">+</button>\n" +
"                        </div>\n" +
"                    </div>\n" +
"                `;\n" +
"            }).join('');\n" +
"\n" +
"            document.getElementById('cartTotal').textContent = 'Rs. ' + total.toFixed(2);\n" +
"            document.getElementById('placeOrderBtn').disabled = false;\n" +
"        }\n" +
"\n" +
"        async function placeOrder() {\n" +
"            const keys = Object.keys(cart);\n" +
"            if (keys.length === 0) return;\n" +
"            const itemsParam = keys.map(id => `${id}:${cart[id]}`).join(',');\n" +
"\n" +
"            try {\n" +
"                const res = await fetch('/api/order', {\n" +
"                    method: 'POST',\n" +
"                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },\n" +
"                    body: 'items=' + encodeURIComponent(itemsParam)\n" +
"                });\n" +
"                const data = await res.json();\n" +
"                if (data.success) {\n" +
"                    cart = {};\n" +
"                    renderCart();\n" +
"                    await loadMenu();\n" +
"                    showToast('Order #' + data.orderId + ' placed successfully!');\n" +
"                    viewOrderDetails(data.orderId);\n" +
"                } else {\n" +
"                    alert('Order failed: ' + data.message);\n" +
"                }\n" +
"            } catch (e) { alert('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        async function loadManageMenu() {\n" +
"            try {\n" +
"                const res = await fetch('/api/menu');\n" +
"                const items = await res.json();\n" +
"                const tbody = document.getElementById('manageTableBody');\n" +
"                tbody.innerHTML = items.map(item => `\n" +
"                    <tr>\n" +
"                        <td><strong>#${item.id}</strong></td>\n" +
"                        <td>\n" +
"                            <span id=\"name_txt_${item.id}\">${item.name}</span>\n" +
"                        </td>\n" +
"                        <td>\n" +
"                            Rs. <span id=\"price_txt_${item.id}\">${item.price.toFixed(2)}</span>\n" +
"                        </td>\n" +
"                        <td>\n" +
"                            <span id=\"qty_txt_${item.id}\">${item.quantity}</span>\n" +
"                        </td>\n" +
"                        <td>\n" +
"                            ${item.quantity > 0 ? '<span style=\"color: var(--success); font-weight: 600;\">Available</span>' : '<span style=\"color: var(--danger); font-weight: 600;\">Out of Stock</span>'}\n" +
"                        </td>\n" +
"                        <td style=\"display: flex; gap: 8px;\">\n" +
"                            <button class=\"btn btn-sm\" onclick=\"promptUpdate(${item.id}, 'price', 'Enter new price for ' + '${item.name}', ${item.price})\">Edit Price</button>\n" +
"                            <button class=\"btn btn-sm\" onclick=\"promptUpdate(${item.id}, 'quantity', 'Enter new quantity for ' + '${item.name}', ${item.quantity})\">Restock Qty</button>\n" +
"                            <button class=\"btn btn-sm btn-danger\" onclick=\"deleteFood(${item.id}, '${item.name}')\">Delete</button>\n" +
"                        </td>\n" +
"                    </tr>\n" +
"                `).join('');\n" +
"            } catch (e) { showToast('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        async function promptUpdate(foodId, field, message, currentVal) {\n" +
"            const val = prompt(message, currentVal);\n" +
"            if (!val || val.trim() === '') return;\n" +
"            try {\n" +
"                const res = await fetch('/api/food/update', {\n" +
"                    method: 'POST',\n" +
"                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },\n" +
"                    body: `foodId=${foodId}&field=${field}&value=${encodeURIComponent(val.trim())}`\n" +
"                });\n" +
"                const data = await res.json();\n" +
"                if (data.success) {\n" +
"                    showToast('Updated successfully!');\n" +
"                    loadManageMenu();\n" +
"                } else {\n" +
"                    alert('Update failed: ' + data.message);\n" +
"                }\n" +
"            } catch (e) { alert('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        async function deleteFood(foodId, name) {\n" +
"            if (!confirm(`Are you sure you want to delete '${name}'?`)) return;\n" +
"            try {\n" +
"                const res = await fetch('/api/food/delete', {\n" +
"                    method: 'POST',\n" +
"                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },\n" +
"                    body: `foodId=${foodId}`\n" +
"                });\n" +
"                const data = await res.json();\n" +
"                if (data.success) {\n" +
"                    if (data.deleted) {\n" +
"                        showToast('Food item permanently deleted!');\n" +
"                    } else {\n" +
"                        showToast(data.message || 'Marked as OUT OF STOCK');\n" +
"                    }\n" +
"                    loadManageMenu();\n" +
"                } else {\n" +
"                    alert('Error: ' + data.message);\n" +
"                }\n" +
"            } catch (e) { alert('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        async function submitAddFood(e) {\n" +
"            e.preventDefault();\n" +
"            const name = document.getElementById('foodName').value;\n" +
"            const price = document.getElementById('foodPrice').value;\n" +
"            const qty = document.getElementById('foodQty').value;\n" +
"\n" +
"            try {\n" +
"                const res = await fetch('/api/food/add', {\n" +
"                    method: 'POST',\n" +
"                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },\n" +
"                    body: `name=${encodeURIComponent(name)}&price=${encodeURIComponent(price)}&quantity=${encodeURIComponent(qty)}`\n" +
"                });\n" +
"                const data = await res.json();\n" +
"                if (data.success) {\n" +
"                    showToast('Item added with ID #' + data.foodId);\n" +
"                    document.getElementById('addFoodForm').reset();\n" +
"                } else {\n" +
"                    alert('Failed: ' + data.message);\n" +
"                }\n" +
"            } catch (err) { alert('Error: ' + err); }\n" +
"        }\n" +
"\n" +
"        async function loadOrders() {\n" +
"            try {\n" +
"                const res = await fetch('/api/orders');\n" +
"                const orders = await res.json();\n" +
"                const tbody = document.getElementById('ordersTableBody');\n" +
"                if (orders.length === 0) {\n" +
"                    tbody.innerHTML = '<tr><td colspan=\"4\" style=\"text-align: center; color: #94a3b8; padding: 30px;\">No orders found.</td></tr>';\n" +
"                    return;\n" +
"                }\n" +
"                tbody.innerHTML = orders.map(o => `\n" +
"                    <tr>\n" +
"                        <td><strong>#${o.id}</strong></td>\n" +
"                        <td>${o.date}</td>\n" +
"                        <td style=\"font-weight: 700; color: var(--primary);\">Rs. ${o.total.toFixed(2)}</td>\n" +
"                        <td>\n" +
"                            <button class=\"btn btn-sm\" onclick=\"viewOrderDetails(${o.id})\">View Receipt</button>\n" +
"                        </td>\n" +
"                    </tr>\n" +
"                `).join('');\n" +
"            } catch (e) { showToast('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        async function viewOrderDetails(orderId) {\n" +
"            try {\n" +
"                const res = await fetch('/api/order/details?id=' + orderId);\n" +
"                const data = await res.json();\n" +
"                if (data.error) { alert(data.error); return; }\n" +
"\n" +
"                document.getElementById('modalTitle').textContent = `🧾 Order Receipt #${data.id}`;\n" +
"                let itemsHtml = data.items.map(item => `\n" +
"                    <div style=\"display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed var(--border); font-size: 14px;\">\n" +
"                        <div>\n" +
"                            <strong>${item.name}</strong> × ${item.qty}\n" +
"                            <div style=\"font-size: 12px; color: #64748b;\">Rs. ${item.price.toFixed(2)} each</div>\n" +
"                        </div>\n" +
"                        <div style=\"font-weight: 600;\">Rs. ${item.subtotal.toFixed(2)}</div>\n" +
"                    </div>\n" +
"                `).join('');\n" +
"\n" +
"                document.getElementById('modalBody').innerHTML = `\n" +
"                    <div style=\"font-size: 13px; color: #64748b; margin-bottom: 16px;\">Date: <strong>${data.date}</strong></div>\n" +
"                    <div style=\"margin-bottom: 20px;\">${itemsHtml}</div>\n" +
"                    <div style=\"display: flex; justify-content: space-between; font-size: 18px; font-weight: 700; color: var(--dark); padding-top: 10px;\">\n" +
"                        <span>Total Amount:</span>\n" +
"                        <span style=\"color: var(--primary);\">Rs. ${data.total.toFixed(2)}</span>\n" +
"                    </div>\n" +
"                `;\n" +
"                document.getElementById('billModal').classList.add('active');\n" +
"            } catch (e) { alert('Error: ' + e); }\n" +
"        }\n" +
"\n" +
"        function closeModal() {\n" +
"            document.getElementById('billModal').classList.remove('active');\n" +
"        }\n" +
"\n" +
"        // Initial Load\n" +
"        loadMenu();\n" +
"    </script>\n" +
"</body>\n" +
"</html>";
    }
}
