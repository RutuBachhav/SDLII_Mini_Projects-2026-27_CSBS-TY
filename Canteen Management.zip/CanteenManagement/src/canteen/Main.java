package canteen;

import java.util.Scanner;

/**
 * Application entry point.
 * Displays the main menu and delegates to CanteenService.
 */
public class Main {

    public static void main(String[] args) {

        CanteenService service = new CanteenService();

        // Warm up the connection early so any misconfiguration is obvious at startup
        try {
            DatabaseConnection.getConnection();
        } catch (Exception e) {
            System.err.println("=======================================================");
            System.err.println("  FATAL: Cannot connect to MySQL.");
            System.err.println("  " + e.getMessage());
            System.err.println("  Check DBConfig.java and make sure MySQL is running.");
            System.err.println("=======================================================");
            System.exit(1);
        }

        Scanner sc = new Scanner(System.in);

        while (true) {
            printMenu();
            System.out.print("Enter your choice: ");
            String input = sc.nextLine().trim();

            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("  [ERROR] Please enter a number between 1 and 8.");
                continue;
            }

            switch (choice) {
                case 1 -> service.addFoodItem(sc);
                case 2 -> service.displayFoodMenu();
                case 3 -> service.takeOrder(sc);
                case 4 -> service.viewOrderHistory();
                case 5 -> service.viewOrderDetails(sc);
                case 6 -> service.updateFoodItem(sc);
                case 7 -> service.deleteFoodItem(sc);
                case 8 -> {
                    System.out.println("\n  Thank you! Closing Canteen Management System.");
                    DatabaseConnection.closeConnection();
                    sc.close();
                    System.exit(0);
                }
                default -> System.out.println("  [ERROR] Invalid choice. Enter 1-8.");
            }
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("=====================================");
        System.out.println("       CANTEEN MANAGEMENT SYSTEM     ");
        System.out.println("=====================================");
        System.out.println("  1. Add Food Item");
        System.out.println("  2. Display Food Menu");
        System.out.println("  3. Take Customer Order");
        System.out.println("  4. View Order History");
        System.out.println("  5. View Order Details");
        System.out.println("  6. Update Food Item");
        System.out.println("  7. Delete Food Item");
        System.out.println("  8. Exit");
        System.out.println("=====================================");
    }
}
