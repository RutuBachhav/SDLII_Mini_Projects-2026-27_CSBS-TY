package canteen;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Model class representing one row in the Orders table.
 * Also holds the associated OrderDetail list for convenience.
 */
public class Order {

    private int           orderId;
    private LocalDateTime orderDate;
    private BigDecimal    totalAmount;
    private List<OrderDetail> details;

    // ------------------------------------------------------------------ //
    // Constructors
    // ------------------------------------------------------------------ //

    public Order() {
        this.details = new ArrayList<>();
    }

    public Order(int orderId, LocalDateTime orderDate, BigDecimal totalAmount) {
        this.orderId     = orderId;
        this.orderDate   = orderDate;
        this.totalAmount = totalAmount;
        this.details     = new ArrayList<>();
    }

    // ------------------------------------------------------------------ //
    // Getters & Setters
    // ------------------------------------------------------------------ //

    public int getOrderId()                         { return orderId; }
    public void setOrderId(int orderId)             { this.orderId = orderId; }

    public LocalDateTime getOrderDate()             { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate){ this.orderDate = orderDate; }

    public BigDecimal getTotalAmount()              { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount){ this.totalAmount = totalAmount; }

    public List<OrderDetail> getDetails()           { return details; }
    public void setDetails(List<OrderDetail> details){ this.details = details; }

    public void addDetail(OrderDetail detail)       { this.details.add(detail); }
}
