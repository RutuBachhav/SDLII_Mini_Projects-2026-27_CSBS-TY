package canteen;

/**
 * Central database configuration.
 * Update these constants to change your MySQL connection settings.
 */
public class DBConfig {

    public static final String HOST     = "localhost";
    public static final String PORT     = "3306";
    public static final String DATABASE = "canteen_db";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "123456789";

    /** Full JDBC URL built from the constants above. */
    public static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    // Prevent instantiation
    private DBConfig() {}
}
