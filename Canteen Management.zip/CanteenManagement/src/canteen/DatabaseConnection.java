package canteen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages the single JDBC connection to MySQL.
 * Call getConnection() wherever a Connection is needed.
 */
public class DatabaseConnection {

    private static Connection connection = null;

    /** Returns a live connection, creating one if necessary. */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(
                        DBConfig.URL, DBConfig.USERNAME, DBConfig.PASSWORD);
                System.out.println("[DB] Connected to " + DBConfig.DATABASE);
            } catch (ClassNotFoundException e) {
                throw new SQLException(
                        "MySQL JDBC Driver not found. Ensure mysql-connector-j-9.7.0.jar is on the classpath.\n"
                        + e.getMessage());
            }
        }
        return connection;
    }

    /** Closes the shared connection (call on application exit). */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Connection closed.");
            } catch (SQLException e) {
                System.err.println("[DB] Error closing connection: " + e.getMessage());
            }
        }
    }
}
