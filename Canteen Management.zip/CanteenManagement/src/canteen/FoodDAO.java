package canteen;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the Food_Items table.
 * All SQL operations on food items are here.
 */
public class FoodDAO {

    // ------------------------------------------------------------------ //
    // INSERT
    // ------------------------------------------------------------------ //

    /**
     * Inserts a new food item into the database.
     * @param foodName name of the food item (must not be blank)
     * @param price    price (must be > 0)
     * @param quantity initial quantity available
     * @return the auto-generated food_id, or -1 on failure
     */
    public int addFoodItem(String foodName, BigDecimal price, int quantity) throws SQLException {
        String sql = "INSERT INTO Food_Items (food_name, price, quantity_available) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, foodName);
            ps.setBigDecimal(2, price);
            ps.setInt(3, quantity);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------ //
    // SELECT ALL
    // ------------------------------------------------------------------ //

    /** Returns every row from Food_Items ordered by food_id. */
    public List<FoodItem> getAllFoodItems() throws SQLException {
        List<FoodItem> list = new ArrayList<>();
        String sql = "SELECT food_id, food_name, price, quantity_available FROM Food_Items ORDER BY food_id";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new FoodItem(
                        rs.getInt("food_id"),
                        rs.getString("food_name"),
                        rs.getBigDecimal("price"),
                        rs.getInt("quantity_available")));
            }
        }
        return list;
    }

    // ------------------------------------------------------------------ //
    // SELECT BY ID
    // ------------------------------------------------------------------ //

    /**
     * Fetches a single FoodItem by its food_id.
     * Returns null if not found.
     */
    public FoodItem getFoodItemById(int foodId) throws SQLException {
        String sql = "SELECT food_id, food_name, price, quantity_available "
                   + "FROM Food_Items WHERE food_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, foodId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new FoodItem(
                            rs.getInt("food_id"),
                            rs.getString("food_name"),
                            rs.getBigDecimal("price"),
                            rs.getInt("quantity_available"));
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ //
    // UPDATE STOCK  (used inside a transaction from OrderDAO)
    // ------------------------------------------------------------------ //

    /**
     * Reduces the available quantity by {@code qty} for the given food item.
     * Must be called within an existing transaction (conn is passed in).
     *
     * @param conn   the transactional connection
     * @param foodId the food item to update
     * @param qty    how many units were ordered
     * @throws SQLException if the update fails or stock would go negative
     */
    public void reduceStock(Connection conn, int foodId, int qty) throws SQLException {
        // Check current stock first (within the same transaction lock)
        String checkSql = "SELECT quantity_available FROM Food_Items WHERE food_id = ? FOR UPDATE";
        try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
            checkPs.setInt(1, foodId);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("Food item ID " + foodId + " not found.");
                }
                int available = rs.getInt("quantity_available");
                if (available < qty) {
                    throw new SQLException(
                            "Insufficient stock for food_id=" + foodId
                            + ". Available: " + available + ", Requested: " + qty);
                }
            }
        }

        String updateSql = "UPDATE Food_Items SET quantity_available = quantity_available - ? "
                         + "WHERE food_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
            ps.setInt(1, qty);
            ps.setInt(2, foodId);
            ps.executeUpdate();
        }
    }

    // ------------------------------------------------------------------ //
    // UPDATE — food name
    // ------------------------------------------------------------------ //

    /**
     * Updates the food_name of an existing item.
     * @return true if a row was updated, false if food_id not found
     */
    public boolean updateFoodName(int foodId, String newName) throws SQLException {
        String sql = "UPDATE Food_Items SET food_name = ? WHERE food_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newName);
            ps.setInt(2, foodId);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------------------------------------------------------ //
    // UPDATE — price
    // ------------------------------------------------------------------ //

    /**
     * Updates the price of an existing item.
     * @return true if a row was updated, false if food_id not found
     */
    public boolean updatePrice(int foodId, BigDecimal newPrice) throws SQLException {
        String sql = "UPDATE Food_Items SET price = ? WHERE food_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, newPrice);
            ps.setInt(2, foodId);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------------------------------------------------------ //
    // UPDATE — quantity (restock / manual correction)
    // ------------------------------------------------------------------ //

    /**
     * Sets quantity_available to an absolute new value (restock or correction).
     * @return true if a row was updated, false if food_id not found
     */
    public boolean updateQuantity(int foodId, int newQty) throws SQLException {
        String sql = "UPDATE Food_Items SET quantity_available = ? WHERE food_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, newQty);
            ps.setInt(2, foodId);
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------------------------------------------------------ //
    // DELETE
    // ------------------------------------------------------------------ //

    /**
     * Permanently deletes a food item by food_id.
     * Will throw a FK constraint error if the item appears in any order.
     * In that case, use updateQuantity(foodId, 0) to mark it unavailable instead.
     * @return true if a row was deleted, false if food_id not found
     */
    public boolean deleteFoodItem(int foodId) throws SQLException {
        String sql = "DELETE FROM Food_Items WHERE food_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, foodId);
            return ps.executeUpdate() > 0;
        }
    }
}
