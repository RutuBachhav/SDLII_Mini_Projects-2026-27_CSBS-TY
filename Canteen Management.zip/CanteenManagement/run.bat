@echo off
rem =============================================================
rem  run.bat
rem  Runs the Canteen Management System.
rem  Make sure compile.bat was executed successfully first.
rem =============================================================

set PROJECT_ROOT=%~dp0
set OUT_DIR=%PROJECT_ROOT%out
set LIB_DIR=%PROJECT_ROOT%lib
set JAR=%LIB_DIR%\mysql-connector-j-9.7.0.jar

echo -----------------------------------------------
echo  Starting Canteen Management System
echo -----------------------------------------------

java -cp "%OUT_DIR%;%JAR%" canteen.Main
pause
