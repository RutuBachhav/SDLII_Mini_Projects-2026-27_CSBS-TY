# Canteen Management System
### Java + JDBC + MySQL | Console-Based | College DBMS Project

---

## Table of Contents
1. [Project Overview](#project-overview)
2. [Web Application & Localhost Link](#web-application--localhost-link)
3. [Project Structure](#project-structure)
4. [Database Design](#database-design)
5. [Features](#features)
6. [Setup Instructions](#setup-instructions)
7. [Compile & Run (Web & Console)](#compile--run)
8. [Sample Session](#sample-session)
9. [Class Interaction Diagram](#class-interaction-diagram)
10. [Viva / Exam Explanation](#viva--exam-explanation)
11. [Troubleshooting](#troubleshooting)

---

## Project Overview

A complete **Canteen Management System** with both a **Web Dashboard (Localhost)** and a **Console Interface** demonstrating:
- Java JDBC with `PreparedStatement` and `try-with-resources`
- JDBC transactions (commit/rollback)
- Proper 3-table relational design with foreign keys
- DAO pattern (Data Access Object)
- Live Web Interface running on localhost with Cart, Orders, Add/Edit Menu, and Receipt Modals
- Separation of concerns across distinct Java classes

---

## Web Application & Localhost Link

The web server is running and accessible at:

🔗 **[http://localhost:8080/](http://localhost:8080/)**

### Web Features:
1. **Interactive Menu & Live Cart:** Add food items to cart with single clicks, adjust quantities, see live price calculations, and place customer orders.
2. **Order Receipt Modal:** Shows itemized bill with subtotals, unit prices, date/time, and grand total.
3. **Inventory Management:** Edit food prices, restock quantities, or delete/mark items out-of-stock.
4. **Add Food Items:** Form to easily add new dishes to the MySQL database.
5. **Order History:** Full list of past orders with one-click receipt views.

### NetBeans & Apache / GlassFish Integration:
The project also includes `web/index.jsp` and configured `web/WEB-INF/lib`.
When opened in **NetBeans IDE**:
- Right-click project &gt; **Clean and Build**
- Right-click project &gt; **Run** (deploys to Apache Tomcat or GlassFish)
- Accessible at: `http://localhost:8080/CanteenManagement/`

---

## Project Structure

```
CanteenManagement/
├── src/
│   └── canteen/
│       ├── DBConfig.java          ← DB credentials (edit here)
│       ├── DatabaseConnection.java← JDBC connection manager
│       ├── FoodItem.java          ← Model: Food_Items table
│       ├── Order.java             ← Model: Orders table
│       ├── OrderDetail.java       ← Model: Order_Details table
│       ├── FoodDAO.java           ← Food DB operations
│       ├── OrderDAO.java          ← Order DB operations (transactional)
│       ├── CanteenService.java    ← Business logic + UI interaction
│       ├── WebServer.java         ← Built-in HTTP Web Server (localhost:8080)
│       └── Main.java              ← Entry point + menu loop
├── web/                           ← Web assets for IDE / server
│   ├── WEB-INF/
│   │   └── lib/
│   │       └── mysql-connector-j-9.7.0.jar
│   └── index.jsp                  ← JSP web dashboard
├── lib/
│   └── mysql-connector-j-9.7.0.jar
├── out/                           ← Compiled .class files (auto-created)
├── schema.sql                     ← Database setup script
├── compile.bat                    ← One-click compile (Windows)
├── run.bat                        ← One-click run console app (Windows)
├── run_web.bat                    ← One-click run web server (Windows)
└── README.md
```

---

## Database Design

```
canteen_db
├── Food_Items
│   ├── food_id            INT  PK  AUTO_INCREMENT
│   ├── food_name          VARCHAR(100)  NOT NULL
│   ├── price              DECIMAL(10,2) NOT NULL  CHECK > 0
│   └── quantity_available INT           NOT NULL  CHECK >= 0
│
├── Orders
│   ├── order_id     INT  PK  AUTO_INCREMENT
│   ├── order_date   DATETIME  NOT NULL
│   └── total_amount DECIMAL(10,2)  NOT NULL
│
└── Order_Details
    ├── detail_id  INT  PK  AUTO_INCREMENT
    ├── order_id   INT  FK → Orders(order_id)  ON DELETE CASCADE
    ├── food_id    INT  FK → Food_Items(food_id)
    ├── quantity   INT           NOT NULL
    ├── unit_price DECIMAL(10,2) NOT NULL   ← price at time of purchase
    └── subtotal   DECIMAL(10,2) NOT NULL
```

> **Why store `unit_price` in Order_Details?**  
> If the menu price changes later, historical bill amounts remain accurate.

---

## Features

| # | Feature | Description |
|---|---------|-------------|
| 1 | Add Food Item | Insert item with name, price, qty. Validates non-empty name and price > 0. |
| 2 | Display Food Menu | Formatted table with status (Available / OUT OF STOCK). |
| 3 | Take Customer Order | Cart-based ordering with multi-item support, stock reservation, confirmation, and JDBC transaction. |
| 4 | View Order History | All past orders with ID, date/time, and total. |
| 5 | View Order Details | Full bill for any past order (fetched from DB, not memory). |
| 6 | Update Food Item | Submenu to update item name, price, or quantity (restock). |
| 7 | Delete Food Item | Permanently deletes item; if referenced in past orders, safely marks as OUT OF STOCK. |
| 8 | Web Dashboard | Full browser-based UI on http://localhost:8080/ with live cart, receipts, and management. |

---

## Setup Instructions

### Step 1 — Install MySQL
Make sure MySQL Server is installed and running on port 3306.

### Step 2 — Create the Database & Tables
Open MySQL command line or MySQL Workbench and run:

```sql
mysql -u root -p < schema.sql
```

Or paste the contents of `schema.sql` into MySQL Workbench and execute.

### Step 3 — Verify MySQL Connector JAR
The file `lib\mysql-connector-j-9.7.0.jar` should already be present.  
If it is missing, copy it manually from:
```
C:\Users\Narsing\AppData\Local\Packages\5319275A.WhatsAppDesktop_cv1g1gvanyjgm\
LocalState\sessions\...\mysql-connector-j-9.7.0\mysql-connector-j-9.7.0.jar
```

### Step 4 — Update Credentials (if needed)
Open `src\canteen\DBConfig.java`:
```java
public static final String USERNAME = "root";
public static final String PASSWORD = "123456789";
public static final String DATABASE = "canteen_db";
```

---

## Compile & Run

### Using batch files (easiest)

```bat
REM Compile all classes (both console and web server)
compile.bat

REM Option A — Launch Web Server (opens http://localhost:8080/)
run_web.bat

REM Option B — Launch Console Menu
run.bat
```

### Manual commands in PowerShell / CMD

```bat
REM Compile
javac -cp "lib\mysql-connector-j-9.7.0.jar" -d out ^
    src\canteen\DBConfig.java ^
    src\canteen\DatabaseConnection.java ^
    src\canteen\FoodItem.java ^
    src\canteen\Order.java ^
    src\canteen\OrderDetail.java ^
    src\canteen\FoodDAO.java ^
    src\canteen\OrderDAO.java ^
    src\canteen\CanteenService.java ^
    src\canteen\WebServer.java ^
    src\canteen\Main.java

REM Run
java -cp "out;lib\mysql-connector-j-9.7.0.jar" canteen.Main
```

---

## Sample Session

```
=====================================
       CANTEEN MANAGEMENT SYSTEM
=====================================
  1. Add Food Item
  2. Display Food Menu
  3. Take Customer Order
  4. View Order History
  5. View Order Details
  6. Exit
=====================================
Enter your choice: 3

--- TAKE CUSTOMER ORDER ---
+------+---------------------------+------------+----------+----------------+
| ID   | Food Name                 | Price(Rs.) | Qty      | Status         |
+------+---------------------------+------------+----------+----------------+
| 1    | Veg Sandwich              |      30.00 | 50       | Available      |
| 2    | Chicken Burger            |      60.00 | 30       | Available      |
...
+------+---------------------------+------------+----------+----------------+

Enter Food ID to add (or 0 to finish): 2
Enter quantity (max 30): 2
  Added: Chicken Burger x2 = Rs.120.00

Enter Food ID to add (or 0 to finish): 4
Enter quantity (max 60): 3
  Added: Cold Coffee x3 = Rs.150.00

Enter Food ID to add (or 0 to finish): 0

+--+---------------------------+------+-----------+-----------+
|  BILL PREVIEW                                              |
+--+---------------------------+------+-----------+-----------+
| # | Item                      | Qty  | Unit Price | Subtotal  |
+--+---------------------------+------+-----------+-----------+
| 1 | Chicken Burger            | 2    | Rs. 60.00 | Rs.120.00 |
| 2 | Cold Coffee               | 3    | Rs. 50.00 | Rs.150.00 |
+--+---------------------------+------+-----------+-----------+
|  GRAND TOTAL                                   Rs.  270.00 |
+--+---------------------------+------+-----------+-----------+

Confirm order? (y/n): y
  [SUCCESS] Order placed! Order ID = 1
```

---

## Class Interaction Diagram

```
Main.java
  │
  └─▶ CanteenService.java  (business logic + console I/O)
         │
         ├─▶ FoodDAO.java      ──▶ Food_Items table
         │      └─▶ DatabaseConnection.java ──▶ MySQL via JDBC
         │
         └─▶ OrderDAO.java     ──▶ Orders + Order_Details tables
                │   (uses FoodDAO.reduceStock inside transaction)
                └─▶ DatabaseConnection.java ──▶ MySQL via JDBC

DBConfig.java  ← used by DatabaseConnection to build the JDBC URL
```

---

## Viva / Exam Explanation

**Q: What is JDBC?**  
Java Database Connectivity — a Java API that lets Java programs connect to any relational database using a driver. We use `DriverManager`, `Connection`, `PreparedStatement`, and `ResultSet`.

**Q: Why `PreparedStatement` instead of `Statement`?**  
It prevents SQL injection by separating the SQL template from user-supplied values, and it is more efficient for repeated executions.

**Q: What is a JDBC transaction? Show where you used it.**  
A transaction groups multiple SQL statements into a single atomic unit. In `OrderDAO.createOrder()`, we:
1. `conn.setAutoCommit(false)` — disable auto-commit
2. Insert into Orders, insert into Order_Details, update Food_Items stock
3. `conn.commit()` — if all succeeded
4. `conn.rollback()` — if any step fails

**Q: What is `try-with-resources`?**  
A Java 7+ construct that automatically closes any `AutoCloseable` (Connection, PreparedStatement, ResultSet) when the block exits, preventing resource leaks.

**Q: Why store `unit_price` in `Order_Details`?**  
So the historical bill remains accurate even if the food item's price is changed or the item is deleted from the menu later.

**Q: What are foreign keys here?**  
`Order_Details.order_id` references `Orders(order_id)` and `Order_Details.food_id` references `Food_Items(food_id)`. This enforces referential integrity — you cannot insert an order detail without a valid order and a valid food item.

**Q: What is the DAO pattern?**  
Data Access Object — a design pattern that separates SQL/database code from business logic. `FoodDAO` and `OrderDAO` handle DB operations; `CanteenService` handles user interaction and logic.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | JAR not on classpath. Check `-cp` includes `lib\mysql-connector-j-9.7.0.jar`. |
| `Access denied for user 'root'` | Wrong password. Update `DBConfig.PASSWORD`. |
| `Unknown database 'canteen_db'` | Run `schema.sql` in MySQL first. |
| `Communications link failure` | MySQL service not running. Start it via Services or `net start mysql`. |
| `CHECK constraint` error on price | Price must be > 0, quantity must be >= 0. |
| Compilation error on switch expressions | Ensure you are using Java 14+ (project uses Java 21). |
