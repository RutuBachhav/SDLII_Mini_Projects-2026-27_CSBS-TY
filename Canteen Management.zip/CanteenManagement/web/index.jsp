<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="canteen.*, java.util.*, java.math.BigDecimal, java.time.format.DateTimeFormatter" %>
<%
    FoodDAO foodDAO = new FoodDAO();
    OrderDAO orderDAO = new OrderDAO();
    DateTimeFormatter dtFmt = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss");

    String message = null;
    String error = null;
    Order placedOrder = null;

    String action = request.getParameter("action");
    if ("addFood".equalsIgnoreCase(action)) {
        try {
            String name = request.getParameter("name");
            BigDecimal price = new BigDecimal(request.getParameter("price"));
            int qty = Integer.parseInt(request.getParameter("quantity"));
            if (name != null && !name.trim().isEmpty() && price.compareTo(BigDecimal.ZERO) > 0 && qty >= 0) {
                int newId = foodDAO.addFoodItem(name.trim(), price, qty);
                message = "Food item '" + name + "' added successfully with ID #" + newId + "!";
            } else {
                error = "Invalid name, price, or quantity.";
            }
        } catch (Exception e) {
            error = "Error adding food item: " + e.getMessage();
        }
    } else if ("placeOrder".equalsIgnoreCase(action)) {
        try {
            List<FoodItem> currentMenu = foodDAO.getAllFoodItems();
            Map<Integer, FoodItem> menuMap = new HashMap<Integer, FoodItem>();
            for (FoodItem fi : currentMenu) menuMap.put(fi.getFoodId(), fi);

            List<OrderDetail> details = new ArrayList<OrderDetail>();
            for (FoodItem fi : currentMenu) {
                String qtyStr = request.getParameter("qty_" + fi.getFoodId());
                if (qtyStr != null && !qtyStr.trim().isEmpty()) {
                    int orderQty = Integer.parseInt(qtyStr.trim());
                    if (orderQty > 0) {
                        if (orderQty > fi.getQuantityAvailable()) {
                            throw new Exception("Requested " + orderQty + " for '" + fi.getFoodName() + "', but only " + fi.getQuantityAvailable() + " available.");
                        }
                        BigDecimal sub = fi.getPrice().multiply(BigDecimal.valueOf(orderQty));
                        details.add(new OrderDetail(fi.getFoodId(), fi.getFoodName(), orderQty, fi.getPrice(), sub));
                    }
                }
            }
            if (details.isEmpty()) {
                error = "Your cart is empty! Please select at least 1 item.";
            } else {
                placedOrder = orderDAO.createOrder(details);
                message = "Order #" + placedOrder.getOrderId() + " placed successfully!";
            }
        } catch (Exception e) {
            error = "Order placement failed: " + e.getMessage();
        }
    } else if ("updatePrice".equalsIgnoreCase(action)) {
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            BigDecimal newPrice = new BigDecimal(request.getParameter("newPrice"));
            if (newPrice.compareTo(BigDecimal.ZERO) > 0) {
                foodDAO.updatePrice(foodId, newPrice);
                message = "Price updated successfully to Rs." + newPrice + "!";
            } else {
                error = "Price must be greater than zero.";
            }
        } catch (Exception e) {
            error = "Error updating price: " + e.getMessage();
        }
    } else if ("updateQty".equalsIgnoreCase(action)) {
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            int newQty = Integer.parseInt(request.getParameter("newQty"));
            if (newQty >= 0) {
                foodDAO.updateQuantity(foodId, newQty);
                message = "Quantity updated successfully to " + newQty + "!";
            } else {
                error = "Quantity cannot be negative.";
            }
        } catch (Exception e) {
            error = "Error updating quantity: " + e.getMessage();
        }
    } else if ("deleteFood".equalsIgnoreCase(action)) {
        try {
            int foodId = Integer.parseInt(request.getParameter("foodId"));
            try {
                boolean del = foodDAO.deleteFoodItem(foodId);
                message = "Food item #" + foodId + " permanently deleted.";
            } catch (Exception ex) {
                foodDAO.updateQuantity(foodId, 0);
                message = "Food item #" + foodId + " appears in past orders. Marked as OUT OF STOCK.";
            }
        } catch (Exception e) {
            error = "Delete failed: " + e.getMessage();
        }
    }

    List<FoodItem> menuItems = foodDAO.getAllFoodItems();
    List<Order> orderHistory = orderDAO.getAllOrders();
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Canteen Management System - JSP</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --success: #10b981;
            --danger: #ef4444;
            --dark: #1e293b;
            --card-bg: #ffffff;
            --bg: #f8fafc;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background: var(--bg); color: #334155; min-height: 100vh; }
        header {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            padding: 24px 32px;
            box-shadow: 0 4px 15px rgba(79, 70, 229, 0.2);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 { font-size: 24px; font-weight: 700; }
        .badge { background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 13px; }
        nav {
            background: white;
            border-bottom: 1px solid var(--border);
            padding: 0 32px;
            display: flex;
            gap: 24px;
        }
        .tab-btn {
            background: none;
            border: none;
            padding: 16px 8px;
            font-size: 15px;
            font-weight: 500;
            color: #64748b;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            text-decoration: none;
        }
        .tab-btn:hover { color: var(--primary); }
        .tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); font-weight: 600; }
        main { padding: 32px; max-width: 1400px; margin: 0 auto; }
        
        .alert { padding: 14px 20px; border-radius: 8px; margin-bottom: 24px; font-size: 14px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

        .btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-block;
        }
        .btn:hover { background: var(--primary-hover); }
        .btn-success { background: var(--success); }
        .btn-success:hover { background: #059669; }
        .btn-danger { background: var(--danger); }
        .btn-danger:hover { background: #dc2626; }
        .btn-sm { padding: 6px 12px; font-size: 12px; border-radius: 6px; }

        .table-container { background: white; border-radius: 12px; border: 1px solid var(--border); overflow-x: auto; margin-bottom: 32px; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
        th { background: #f8fafc; padding: 14px 20px; font-weight: 600; color: #475569; border-bottom: 1px solid var(--border); }
        td { padding: 14px 20px; border-bottom: 1px solid var(--border); color: #334155; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #f8fafc; }

        .form-card {
            background: white;
            border-radius: 12px;
            border: 1px solid var(--border);
            padding: 28px;
            margin-bottom: 32px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.04);
        }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; color: #475569; }
        .form-control {
            width: 100%;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid var(--border);
            font-size: 14px;
        }
        .qty-input { width: 80px; text-align: center; }
        .receipt-card {
            background: #fff;
            border: 2px solid var(--primary);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 32px;
            box-shadow: 0 8px 25px rgba(79, 70, 229, 0.15);
        }
    </style>
</head>
<body>

    <header>
        <h1>🍽️ Canteen Management System <span class="badge">JSP + MySQL + JDBC</span></h1>
        <div style="font-size: 13px; opacity: 0.9;">Database: <strong>canteen_db</strong></div>
    </header>

    <main>
        <% if (message != null) { %>
            <div class="alert alert-success"><strong>✓ Success:</strong> <%= message %></div>
        <% } %>
        <% if (error != null) { %>
            <div class="alert alert-danger"><strong>⚠️ Error:</strong> <%= error %></div>
        <% } %>

        <% if (placedOrder != null) { %>
            <div class="receipt-card">
                <h2 style="color: var(--primary); margin-bottom: 12px;">🧾 Order Placed Successfully! (Order #<%= placedOrder.getOrderId() %>)</h2>
                <p style="font-size: 13px; color: #64748b; margin-bottom: 16px;">Date: <strong><%= placedOrder.getOrderDate().format(dtFmt) %></strong></p>
                <div class="table-container" style="box-shadow: none;">
                    <table>
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (OrderDetail od : placedOrder.getDetails()) { %>
                                <tr>
                                    <td><strong><%= od.getFoodName() %></strong></td>
                                    <td><%= od.getQuantity() %></td>
                                    <td>Rs. <%= od.getUnitPrice() %></td>
                                    <td>Rs. <%= od.getSubtotal() %></td>
                                </tr>
                            <% } %>
                            <tr style="background: #f1f5f9; font-weight: 700;">
                                <td colspan="3" style="text-align: right;">Grand Total:</td>
                                <td style="color: var(--primary); font-size: 16px;">Rs. <%= placedOrder.getTotalAmount() %></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        <% } %>

        <!-- SECTION 1: TAKE CUSTOMER ORDER -->
        <h2 style="margin-bottom: 16px;">🛒 Food Menu & Take Customer Order</h2>
        <form method="POST" action="index.jsp">
            <input type="hidden" name="action" value="placeOrder">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Food Name</th>
                            <th>Price (Rs.)</th>
                            <th>Available Qty</th>
                            <th>Status</th>
                            <th>Order Qty</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (FoodItem item : menuItems) { %>
                            <tr>
                                <td>#<%= item.getFoodId() %></td>
                                <td><strong><%= item.getFoodName() %></strong></td>
                                <td>Rs. <%= item.getPrice() %></td>
                                <td><%= item.getQuantityAvailable() %></td>
                                <td>
                                    <% if (item.getQuantityAvailable() > 0) { %>
                                        <span style="color: var(--success); font-weight: 600;">● Available</span>
                                    <% } else { %>
                                        <span style="color: var(--danger); font-weight: 600;">● Out of Stock</span>
                                    <% } %>
                                </td>
                                <td>
                                    <% if (item.getQuantityAvailable() > 0) { %>
                                        <input type="number" name="qty_<%= item.getFoodId() %>" min="0" max="<%= item.getQuantityAvailable() %>" value="0" class="form-control qty-input">
                                    <% } else { %>
                                        <input type="number" disabled value="0" class="form-control qty-input">
                                    <% } %>
                                </td>
                            </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
            <div style="text-align: right; margin-bottom: 40px;">
                <button type="submit" class="btn btn-success" style="padding: 12px 28px; font-size: 16px;">Place Customer Order</button>
            </div>
        </form>

        <!-- SECTION 2: ADD NEW FOOD ITEM -->
        <div class="form-card">
            <h2 style="margin-bottom: 20px;">➕ Add New Food Item</h2>
            <form method="POST" action="index.jsp" style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 16px; align-items: end;">
                <input type="hidden" name="action" value="addFood">
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Food Item Name</label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Masala Chai" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Price (Rs.)</label>
                    <input type="number" step="0.5" min="1" name="price" class="form-control" placeholder="20.00" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Quantity</label>
                    <input type="number" min="0" name="quantity" class="form-control" placeholder="50" required>
                </div>
                <button type="submit" class="btn" style="height: 42px;">Add Food Item</button>
            </form>
        </div>

        <!-- SECTION 3: ORDER HISTORY -->
        <h2 style="margin-bottom: 16px;">📜 Order History</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Order Date & Time</th>
                        <th>Total Amount</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (orderHistory.isEmpty()) { %>
                        <tr><td colspan="4" style="text-align: center; color: #94a3b8; padding: 24px;">No past orders found.</td></tr>
                    <% } else { %>
                        <% for (Order o : orderHistory) { %>
                            <tr>
                                <td><strong>#<%= o.getOrderId() %></strong></td>
                                <td><%= o.getOrderDate().format(dtFmt) %></td>
                                <td style="font-weight: 700; color: var(--primary);">Rs. <%= o.getTotalAmount() %></td>
                                <td>
                                    <form method="GET" action="index.jsp" style="display:inline;">
                                        <input type="hidden" name="viewOrderId" value="<%= o.getOrderId() %>">
                                        <button type="button" class="btn btn-sm" onclick="alert('Order #<%= o.getOrderId() %> Details:\nTotal: Rs. <%= o.getTotalAmount() %>\nDate: <%= o.getOrderDate().format(dtFmt) %>')">View Quick Summary</button>
                                    </form>
                                </td>
                            </tr>
                        <% } %>
                    <% } %>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
