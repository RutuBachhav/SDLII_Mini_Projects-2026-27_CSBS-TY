@echo off
rem =============================================================
rem  run_web.bat
rem  Starts the Canteen Management System Web Server on localhost:8080
rem =============================================================

set PROJECT_ROOT=%~dp0
set OUT_DIR=%PROJECT_ROOT%out
set LIB_DIR=%PROJECT_ROOT%lib
set JAR=%LIB_DIR%\mysql-connector-j-9.7.0.jar

echo -------------------------------------------------------------
echo  Starting Canteen Management System Web Server
echo  Open your browser at: http://localhost:8080/
echo -------------------------------------------------------------

java -cp "%OUT_DIR%;%JAR%" canteen.WebServer 8080
pause
