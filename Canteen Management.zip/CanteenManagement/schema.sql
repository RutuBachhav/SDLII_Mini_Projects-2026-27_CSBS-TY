-- =============================================================
--  Canteen Management System — Database Schema
--  Database : canteen_db
--  Run this file once to create the schema and seed data.
--  Command  : mysql -u root -p < schema.sql
-- =============================================================

-- Create (or re-use) the database
CREATE DATABASE IF NOT EXISTS canteen_db
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE canteen_db;

-- =============================================================
--  TABLE 1 : Food_Items
-- =============================================================
CREATE TABLE IF NOT EXISTS Food_Items (
    food_id            INT          NOT NULL AUTO_INCREMENT,
    food_name          VARCHAR(100) NOT NULL,
    price              DECIMAL(10,2) NOT NULL CHECK (price > 0),
    quantity_available INT          NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
    PRIMARY KEY (food_id)
) ENGINE=InnoDB;

-- =============================================================
--  TABLE 2 : Orders
-- =============================================================
CREATE TABLE IF NOT EXISTS Orders (
    order_id     INT           NOT NULL AUTO_INCREMENT,
    order_date   DATETIME      NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (order_id)
) ENGINE=InnoDB;

-- =============================================================
--  TABLE 3 : Order_Details
-- =============================================================
CREATE TABLE IF NOT EXISTS Order_Details (
    detail_id  INT           NOT NULL AUTO_INCREMENT,
    order_id   INT           NOT NULL,
    food_id    INT           NOT NULL,
    quantity   INT           NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal   DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (detail_id),
    CONSTRAINT fk_od_order FOREIGN KEY (order_id)
        REFERENCES Orders(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_od_food  FOREIGN KEY (food_id)
        REFERENCES Food_Items(food_id)
) ENGINE=InnoDB;

-- =============================================================
--  SAMPLE FOOD ITEMS  (optional — remove if not needed)
-- =============================================================
INSERT INTO Food_Items (food_name, price, quantity_available) VALUES
    ('Veg Sandwich',      30.00, 50),
    ('Chicken Burger',    60.00, 30),
    ('Masala Dosa',       40.00, 40),
    ('Cold Coffee',       50.00, 60),
    ('Veg Fried Rice',    70.00, 25),
    ('Paneer Wrap',       55.00, 35),
    ('Fresh Lime Soda',   25.00, 80),
    ('Chocolate Cake',    45.00, 20);
